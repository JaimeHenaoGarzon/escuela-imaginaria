<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bdfases";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("La conexión falló: " . $conn->connect_error);
}

// Consulta para obtener los roles
$sql = "SELECT * FROM roles";
$result = $conn->query($sql);

// Preparar un array para almacenar los roles
$roles = array();

// Obtener los roles como opciones en el menú desplegable
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $roles[] = array(
            'id' => $row['idrol'],
            'rol' => $row['rol']
        );
    }
} else {
    $roles[] = array(
        'id' => '',
        'rol' => 'No hay roles disponibles'
    );
}

$conn->close();

// Devolver los roles como JSON
header('Content-Type: application/json');
echo json_encode($roles);
?>