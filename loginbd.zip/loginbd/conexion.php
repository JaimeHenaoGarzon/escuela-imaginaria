<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "bdfases"; 


$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error: No se pudo conectar a la base de datos. " . $conn->connect_error);
}
?>

