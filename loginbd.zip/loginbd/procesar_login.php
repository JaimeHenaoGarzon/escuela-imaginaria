<?php
// Verificar si se han enviado los datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $username = $_POST['username'];
    $password = $_POST['password'];
    $rol = $_POST['rol'];

    // Conexión a la base de datos
    $servername = "localhost";
    $db_username = "root"; 
    $db_password = ""; 
    $dbname = "bdfases";

    // Crear conexión
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("La conexión falló: " . $conn->connect_error);
    }

    // Consulta SQL para verificar el usuario y la contraseña en la tabla 'usuario'
    $sql_user = "SELECT * FROM usuario WHERE cedula='$username' AND contraseña='$password'";
    $result_user = $conn->query($sql_user);

    if ($result_user->num_rows == 1) {
        // Consulta SQL para verificar el rol del usuario en la tabla 'rol_user'
        $sql_rol = "SELECT * FROM rol_user WHERE cedula='$username' AND idrol='$rol'";
        $result_rol = $conn->query($sql_rol);

        if ($result_rol->num_rows == 1) {
            // Usuario y contraseña válidos y rol asignado, iniciar sesión
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['rol'] = $rol;
            $mensaje = "Sesión iniciada correctamente";
            header("Location: inicio.html");
        } else {
            // Rol no asignado al usuario
            echo "<script>alert('El usuario no tiene acceso con el rol seleccionado'); window.location.href='index.html';</script>";
            
        }
    } else {
        // Usuario o contraseña incorrectos
      
        echo "<script>alert('Usuario o contraseña incorrectos.'); window.location.href='index.html';</script>";
    }

    // Cerrar conexión
    $conn->close();
}
?>