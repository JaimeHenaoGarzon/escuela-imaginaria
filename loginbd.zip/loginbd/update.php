<?php
include "conexion.php"; // Asegúrate de incluir tu archivo de conexión

// Verificar conexión
if (!$conn) {
    die("Error: No se pudo conectar a la base de datos.");
}

// Obtener datos del formulario
$cedula = $_POST['cedula'];
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellido'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];
$sueldo = $_POST['sueldo'];
$roles = $_POST['rol']; // Asegúrate de que se recibe como array si es necesario

// Actualizar datos del empleado
$sql_update = "UPDATE usuario SET nombre='$nombre', apellidos='$apellidos', direccion='$direccion', telefono='$telefono', correo='$correo', sueldo='$sueldo' WHERE cedula='$cedula'";

if ($conn->query($sql_update) === TRUE) {
    // Eliminar roles anteriores del usuario
    $sql_delete_roles = "DELETE FROM rol_user WHERE cedula='$cedula'";
    if ($conn->query($sql_delete_roles) === TRUE) {
        // Insertar los nuevos roles seleccionados
        foreach ($roles as $rol) {
            $sql_insert_rol = "INSERT INTO rol_user (idrol, cedula) VALUES ('$rol', '$cedula')";
            if ($conn->query($sql_insert_rol) !== TRUE) {
                echo "Error al asignar roles: " . $conn->error;
            }
        }
        echo "<script>alert('Los datos del usuario fueron actualizados exitosamente.'); window.location.href='formularioEmpleado.php';</script>";
    } else {
        echo "Error al eliminar roles anteriores: " . $conn->error;
    }
} else {
    echo "Error al actualizar datos: " . $conn->error;
}

$conn->close(); // Cierra la conexión al finalizar el script
?>