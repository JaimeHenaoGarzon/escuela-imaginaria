<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bdfases";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("La conexión falló: " . $conn->connect_error);
}

$registros = mysqli_query($conn, "SELECT u.cedula, u.nombre, u.apellidos, u.direccion, u.telefono, u.correo, r.rol AS cargo, u.sueldo
                        FROM usuario u
                        INNER JOIN rol_user ru ON u.cedula = ru.cedula
                        INNER JOIN roles r ON ru.idrol = r.idrol") or
    die("Problemas en el select:" . mysqli_error($conn));

while ($reg = mysqli_fetch_array($registros)) {
    echo "Cedula: " . $reg['cedula'] . "<br>";
    echo "Nombre: " . $reg['nombre'] . "<br>";
    echo "Apellido: " . $reg['apellidos'] . "<br>";
    echo "Direccion: " . $reg['direccion'] . "<br>";
    echo "Telefono: " . $reg['telefono'] . "<br>";
    echo "Correo: " . $reg['correo'] . "<br>";
    echo "Cargo: " . $reg['cargo'] . "<br>";
    echo "Sueldo: " . $reg['sueldo'] . "<br>";
    echo "<br>";
    echo "<hr>";
}

mysqli_close($conn);
?>